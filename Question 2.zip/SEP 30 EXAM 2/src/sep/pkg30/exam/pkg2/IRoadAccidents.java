/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sep.pkg30.exam.pkg2;

/**
 *
 * @author Joel
 */
public interface IRoadAccidents{
String getAccidentVehicleType();
String getCity();
int getAccidentTotal();
    
    
    
}
